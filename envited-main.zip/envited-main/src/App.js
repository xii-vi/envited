import { CreateEvent } from "./pages/CreateEvent";
import { Events } from "./pages/Events";
import { Homepage } from "./pages/Homepage";
import { Routes, Route } from "react-router-dom";

function App() {
  return (
  <>
  <Routes>
    <Route path='/' element={<Homepage />} />
    <Route path='/create' element={<CreateEvent />} />
    <Route path='/event' element={<Events />} />
  </Routes>
  </>
  );
}

export default App;
