import { useForm } from "../context/FormContext"

export const InputField =({label,type,placeholder,name,value})=>{
    const {formState,setFormState } = useForm();
    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormState({ ...formState, [name]: value });
      };
    return(
        <>
        <div className="flex flex-col">
            <div className="text-xl mt-2">
            <label htmlFor={name} >{label}</label> 
            </div>
            <input
            className="p-4" 
            type={type} 
            placeholder={placeholder}
            name={name}
            value={value}
            onChange={handleInputChange}
            />
            
            
        </div>
        </>
    )
}