export const EventCard =({eventData,eventBanner})=>{
    const {hostName,eventLocation,eventName,startDate,endDate} = eventData;
    return(
        <>
        <div>
            <img src={eventBanner} alt={eventName} />
            <div>
                <div>{eventName}</div>
                <p>{hostName}</p>
                <div>{startDate} to {endDate}</div>
                <div>{eventLocation}</div>
            </div>
        </div>
        </>
    )
}