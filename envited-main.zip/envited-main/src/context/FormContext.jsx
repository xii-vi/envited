import { createContext,useContext,useState } from "react";

const FormContext = createContext();

const FormProvider = ({children})=>{
    const [formState,setFormState] = useState({
        eventName:'',
        hostName:'',
        startDate:'',
        endDate:'',
        eventLocation:'',
    })
    const [imgData,setImageData] = useState({eventBanner:'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_640.png'})
    return(
        <FormContext.Provider value={{formState,setFormState,imgData,setImageData}}>
            {children}
        </FormContext.Provider>
    )
}

const useForm = () => useContext(FormContext);

export {useForm,FormProvider}