import { InputField } from "../components/InputField"
import { useForm } from "../context/FormContext"
import { Link } from "react-router-dom"

export const CreateEvent = () =>{
    const {formState,setImageData} = useForm();
    const imageHandler =(event)=>{
        const reader = new FileReader();
        reader.onload =()=>{
            if(reader.readyState===2){
                setImageData({eventBanner:reader.result})
            }
        }
        reader.readAsDataURL(event.target.files[0])
    }

    const submitHandler =(event)=>{
        event.preventDefault();
    }
    return(
        <>
        <form onSubmit={submitHandler} className='m-4'>
        <InputField 
            label='Event Name'
            type='text' 
            placeholder='Enter Event Name'
            name='eventName'
            value={formState.eventName}
        />
        <InputField 
            label='Host Name'
            type='text' 
            placeholder='Enter Host Name'
            name='hostName'
            value={formState.hostName}
        />
        <InputField 
            label='Start Date'
            type='date' 
            placeholder='DD-MM-YYYY'
            name='startDate'
            value={formState.startDate}
        />
        <InputField 
            label='End Date'
            type='date' 
            placeholder='DD-MM-YYYY'
            name='endDate'
            value={formState.endDate}
        />
        <InputField 
            label='Event Location'
            type='text' 
            placeholder='Enter Event Location'
            name='eventLocation'
            value={formState.eventLocation}
        />
        <input 
            label='Event Banner'
            type='file' 
            name='eventBanner'
            accept="image/*"
            value={formState.eventBanner}
            onChange={imageHandler}
        />
        </form>
        <Link to="/"><button>Back</button></Link>
        <Link to="/event">
        <button type='submit' className="pt-4">Create Event</button>
        </Link>
        </>
        )
}