import { EventCard } from "../components/EventCard"
import { useForm } from "../context/FormContext"
import { Link } from "react-router-dom"

export const Events=()=>{
    const {formState,imgData} = useForm();
    return(
        <>
        <EventCard eventData={formState} eventBanner = {imgData}/>
        <Link to="/create"><button>Back</button></Link>
        </>
    )
}