/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js,jsx}"],
  theme: {
    colors:{
      primary:{
        blue:'#240D57',
        purple1:'#501FC1',
        purple2:'#8456EC',
        purple3:'#E87BF8',
      },
      secondary:{
        purpleShade1:'#CCB6FF',
        purpleShade2:'#EDE5FF',
        purpleShade3:'#F6F2FF',
      }
    },
    extend: {},
  },
  plugins: [],
}
